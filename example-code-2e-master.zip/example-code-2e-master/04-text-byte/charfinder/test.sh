#!/bin/bash
python3 -m doctest README.rst $1
