from birds import *

woody = Bird()
alert(woody)
alert_duck(woody)
alert_bird(woody)
