def double(n: object) -> object:
    return n * 2
