from collections import abc
from typing import Any

def double(x: abc.Sequence) -> Any:
    return x * 2

