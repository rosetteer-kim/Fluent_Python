from clip_annot_post import clip

print(clip.__annotations__)
